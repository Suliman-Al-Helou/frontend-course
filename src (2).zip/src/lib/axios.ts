import axios from 'axios';
import type { LessonProgress, Task, TaskResult } from '@/types';

// إنشاء نسخة Axios موجهة بالكامل إلى الـ Proxy الداخلي لتطبيق Next.js
const api = axios.create({
  baseURL: '/api', // تم التعديل هنا: يذهب إلى الـ Proxy التلقائي بدلاً من الرابط المباشر المكشوف
  headers: {
    'Content-Type': 'application/json',
    'Accept':       'application/json',
  },
});

export default api;

// الـ APIs الخاصة بالدروس والمهام (تستدعى داخل الـ Client Components)
export const lessonApi = {
  getProgress: (lessonId: number) =>
    api.get<LessonProgress>(`/lessons/${lessonId}/progress`),

  saveProgress: (lessonId: number, data: { watched_percent: number; last_position: number }) =>
    api.post(`/lessons/${lessonId}/progress`, data),

  getTask: (lessonId: number) =>
    api.get<Task>(`/lessons/${lessonId}/task`),

  submitTask: (lessonId: number, answers: Record<string, string>) =>
    api.post<TaskResult>(`/lessons/${lessonId}/task`, { answers }),
};
