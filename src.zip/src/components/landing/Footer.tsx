// 1. Imports
import Link from "next/link";
import {
  Twitter,
  Youtube,
  Linkedin,
  Instagram,
  LucideIcon,
} from "lucide-react";
import LogoIcon from "@/components/Logo";
// 2. Types & Data
interface SocialLink {
  icon: LucideIcon;
  href: string;
  label: string;
}

const FOOTER_LINKS: Record<string, string[]> = {
  الكورسات: [
    "Python",
    "JavaScript",
    "React",
    "الذكاء الاصطناعي",
    "قواعد البيانات",
  ],
  المنصة: ["كيف تعمل؟", "الأسعار", "المدربون", "الشهادات"],
  الدعم: ["مركز المساعدة", "تواصل معنا", "سياسة الخصوصية", "الشروط والأحكام"],
};

const SOCIALS: SocialLink[] = [
  { icon: Twitter, href: "#", label: "Twitter" },
  { icon: Youtube, href: "#", label: "YouTube" },
  { icon: Linkedin, href: "#", label: "LinkedIn" },
  { icon: Instagram, href: "#", label: "Instagram" },
];

// 3. Sub Components
// أضف الـ import


// عدّل Brand()
function Brand() {
  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        <LogoIcon size={36} className="brightness-0 invert"/>
        <span className="text-xl font-bold">
         Future<span className="text-background pl-1">House</span>
        </span>
      </div>
      <p className="text-white/60 text-sm leading-relaxed mb-5">
        منصة تعليمية عربية متكاملة لتعلم البرمجة والتقنية باحترافية.
      </p>
      <div className="flex items-center gap-3">
        {SOCIALS.map(({ icon: Icon, href, label }) => (
          <a
            key={label}
            href={href}
            aria-label={label}
            className="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
          >
            <Icon className="w-4 h-4 text-white/80" />
          </a>
        ))}
      </div>
    </div>
  );
}

interface LinkColumnProps {
  category: string;
  items: string[];
}

function LinkColumn({ category, items }: LinkColumnProps) {
  return (
    <div>
      <h4 className="font-bold text-white mb-4">{category}</h4>
      <ul className="space-y-2.5">
        {items.map((item) => (
          <li key={item}>
            <Link
              href="#"
              className="text-white/60 hover:text-white text-sm transition-colors"
            >
              {item}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

// 4. Main Component
export default function Footer() {
  return (
    <footer className="bg-blue-deep text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-4 gap-10 mb-12">
          <Brand />
          {Object.entries(FOOTER_LINKS).map(([category, items]) => (
            <LinkColumn key={category} category={category} items={items} />
          ))}
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-white/40 text-sm">
            © 2026 Future House. جميع الحقوق محفوظة.
          </p>
          <p className="text-white/40 text-sm">صُنع بـ ❤️ للمتعلمين العرب</p>
        </div>
      </div>
    </footer>
  );
}
