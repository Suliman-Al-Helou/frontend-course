"use client";

import { useState, useEffect, Suspense } from "react";
import { motion } from "framer-motion";
import {
  Shield, Plus, LogOut, LayoutDashboard,
  Users, BookOpen, ClipboardList, GraduationCap,
  Moon, Sun, ChevronDown, MessageCircleQuestion,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuthStore } from "@/store/authStore";
import { useThemeStore } from "@/store/themeStore";
import Cookies from "js-cookie";
import api from "@/lib/api";
import AdminStatsCards        from "@/components/admin/AdminStatsCards";
import EnrollmentRequests     from "@/components/admin/EnrollmentRequests";
import StudentsTable          from "@/components/admin/StudentsTable";
import CoursesOverview        from "@/components/admin/CoursesOverview";
import AddEnrollmentModal     from "@/components/admin/AddEnrollmentModal";
import ManageCoursesTab       from "@/components/admin/ManageCoursesTab";
import ManageInstructorsTab   from "@/components/admin/ManageInstructorsTab";
import ManageFaqTab           from "@/components/admin/ManageFaqTab";
import type { Enrollment, AdminUser, AdminStats } from "@/types";
import { useRouter, useSearchParams } from "next/navigation";

const TABS = [
  { id: "overview",     label: "نظرة عامة",         icon: LayoutDashboard       },
  { id: "enrollments",  label: "طلبات التسجيل",     icon: ClipboardList         },
  { id: "students",     label: "الطلاب",             icon: Users                 },
  { id: "courses",      label: "الكورسات",           icon: BookOpen              },
  { id: "instructors",  label: "المدربون",           icon: GraduationCap         },
  { id: "faqs",         label: "الأسئلة الشائعة",   icon: MessageCircleQuestion },
] as const;

type TabId = (typeof TABS)[number]["id"];

const TAB_LABELS: Record<TabId, string> = {
  overview:    "نظرة عامة",
  enrollments: "طلبات التسجيل",
  students:    "الطلاب",
  courses:     "الكورسات",
  instructors: "المدربون",
  faqs:        "الأسئلة الشائعة",
};

function ThemeToggle() {
  const { theme, toggleTheme } = useThemeStore();
  return (
    <button
      onClick={toggleTheme}
      className="p-2 rounded-xl text-foreground/70 hover:bg-accent/10 hover:text-primary transition-colors"
      aria-label="تبديل الوضع الليلي"
    >
      {theme === "dark" ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
    </button>
  );
}

function AdminContent() {
  const { user, logout } = useAuthStore();
  const searchParams = useSearchParams();
  const router       = useRouter();
  const tab          = (searchParams.get("tab") as TabId) ?? "overview";

  const setTab = (newTab: TabId) => {
    router.push(`/admin?tab=${newTab}`, { scroll: false });
    setMobileMenuOpen(false);
  };

  const [enrollments,    setEnrollments]    = useState<Enrollment[]>([]);
  const [users,          setUsers]          = useState<AdminUser[]>([]);
  const [stats,          setStats]          = useState<AdminStats>({
    totalStudents: 0, totalCourses: 0, totalInstructors: 0, pendingEnrollments: 0,
  });
  const [showModal,      setShowModal]      = useState(false);
  const [loading,        setLoading]        = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [enrRes, usrRes, coursesRes, instructorsRes] = await Promise.all([
        api.get("/admin/enrollments"),
        api.get("/admin/users"),
        api.get("/admin/courses"),
        api.get("/admin/instructors"),
      ]);
      const enrData = enrRes.data.data       ?? enrRes.data;
      const usrData = usrRes.data.data        ?? usrRes.data;
      const crsData = coursesRes.data.data     ?? coursesRes.data;
      const insData = instructorsRes.data.data ?? instructorsRes.data;
      setEnrollments(enrData);
      setUsers(usrData);
      setStats({
        totalStudents:      usrData.filter((u: any) => u.role !== "admin").length,
        totalCourses:       Array.isArray(crsData) ? crsData.length : 0,
        totalInstructors:   Array.isArray(insData) ? insData.length : 0,
        pendingEnrollments: enrData.filter((e: any) => e.status === "pending").length,
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const handleLogout = () => {
    logout();
    Cookies.remove("auth-token");
    router.push("/");
  };

  if (user && user.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background" dir="rtl">
        <div className="text-center">
          <Shield className="w-16 h-16 text-destructive mx-auto mb-4" />
          <h2 className="text-xl font-bold text-foreground">غير مصرح لك بالدخول</h2>
          <p className="text-muted-foreground mt-2">هذه الصفحة للأدمن فقط</p>
        </div>
      </div>
    );
  }

  const currentTab = TABS.find(t => t.id === tab);

  return (
    <div className="min-h-screen bg-background font-arabic" dir="rtl">
      <div className="flex">

        {/* Sidebar — Desktop */}
        <aside className="hidden lg:flex flex-col w-64 min-h-screen bg-card border-l border-border fixed right-0 top-0 z-30">
          <div className="p-6 border-b border-border">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 bg-primary rounded-xl flex items-center justify-center">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="font-bold text-foreground text-sm">لوحة الأدمن</p>
                <p className="text-xs text-muted-foreground">future house</p>
              </div>
            </div>
          </div>

          <nav className="flex-1 p-4 space-y-1">
            {TABS.map(t => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                  tab === t.id
                    ? "bg-primary text-white shadow-md"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
              >
                <t.icon className="w-4 h-4" />
                {t.label}
                {t.id === "enrollments" && stats.pendingEnrollments > 0 && (
                  <span className={`mr-auto text-xs px-2 py-0.5 rounded-full font-bold ${
                    tab === "enrollments"
                      ? "bg-white/20 text-white"
                      : "bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400"
                  }`}>
                    {stats.pendingEnrollments}
                  </span>
                )}
              </button>
            ))}
          </nav>

          <div className="p-4 border-t border-border space-y-2">
            <div className="flex items-center justify-between px-2">
              <span className="text-xs text-muted-foreground">الوضع الليلي</span>
              <ThemeToggle />
            </div>
            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors"
            >
              <LogOut className="w-4 h-4" />
              تسجيل الخروج
            </button>
          </div>
        </aside>

        {/* Main */}
        <main className="flex-1 lg:mr-64 min-h-screen">

          {/* Header */}
          <header className="sticky top-0 z-20 bg-card/80 backdrop-blur-xl border-b border-border px-4 sm:px-6 h-16 flex items-center justify-between">
            <div>
              <h1 className="font-bold text-foreground text-sm sm:text-base">{TAB_LABELS[tab]}</h1>
              <p className="text-xs text-muted-foreground hidden sm:block">مرحباً {user?.name}</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="lg:hidden"><ThemeToggle /></div>

            </div>
          </header>

          {/* Mobile Nav — Dropdown */}
          <div className="lg:hidden px-4 py-3 border-b border-border bg-card relative">
            <button
              onClick={() => setMobileMenuOpen(o => !o)}
              className="w-full flex items-center justify-between bg-muted px-4 py-2.5 rounded-xl text-sm font-medium text-foreground"
            >
              <span className="flex items-center gap-2">
                {currentTab && <currentTab.icon className="w-4 h-4 text-primary" />}
                {TAB_LABELS[tab]}
                {tab === "enrollments" && stats.pendingEnrollments > 0 && (
                  <span className="bg-orange-100 dark:bg-orange-900/30 text-orange-600 text-xs px-2 py-0.5 rounded-full font-bold">
                    {stats.pendingEnrollments}
                  </span>
                )}
              </span>
              <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${mobileMenuOpen ? 'rotate-180' : ''}`} />
            </button>

            {mobileMenuOpen && (
              <div className="absolute top-full right-4 left-4 mt-1 bg-card border border-border rounded-2xl shadow-xl z-50 overflow-hidden">
                {TABS.map(t => (
                  <button
                    key={t.id}
                    onClick={() => setTab(t.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium transition-colors border-b border-border/50 last:border-0 ${
                      tab === t.id
                        ? 'bg-primary/10 text-primary'
                        : 'text-foreground hover:bg-muted'
                    }`}
                  >
                    <t.icon className="w-4 h-4" />
                    {t.label}
                    {t.id === "enrollments" && stats.pendingEnrollments > 0 && (
                      <span className="mr-auto bg-orange-100 dark:bg-orange-900/30 text-orange-600 text-xs px-2 py-0.5 rounded-full font-bold">
                        {stats.pendingEnrollments}
                      </span>
                    )}
                    {tab === t.id && (
                      <span className="mr-auto text-primary text-xs">✓</span>
                    )}
                  </button>
                ))}
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-3 px-4 py-3 text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors border-t border-border mt-1"
                >
                  <LogOut className="w-4 h-4" />
                  تسجيل الخروج
                </button>
              </div>
            )}
          </div>

          {/* Content */}
          <div className="p-4 sm:p-6 lg:p-8">
            {loading ? (
              <div className="flex items-center justify-center py-20">
                <div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
              </div>
            ) : (
              <>
                {tab === "overview" && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                    <AdminStatsCards stats={stats} />
                    <div className="grid lg:grid-cols-2 gap-6">
                      <EnrollmentRequests enrollments={enrollments} onRefresh={fetchData} />
                      <CoursesOverview enrollments={enrollments} />
                    </div>
                  </motion.div>
                )}
                {tab === "enrollments" && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                    <EnrollmentRequests enrollments={enrollments} onRefresh={fetchData} />
                  </motion.div>
                )}
                {tab === "students" && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                    <StudentsTable users={users} enrollments={enrollments} onRefresh={fetchData} />
                  </motion.div>
                )}
                {tab === "courses" && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                    <ManageCoursesTab enrollments={enrollments} />
                  </motion.div>
                )}
                {tab === "instructors" && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                    <ManageInstructorsTab />
                  </motion.div>
                )}
                {tab === "faqs" && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                    <ManageFaqTab />
                  </motion.div>
                )}
              </>
            )}
          </div>
        </main>
      </div>


    </div>
  );
}

export default function AdminPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    }>
      <AdminContent />
    </Suspense>
  );
}