'use client';

import YouTube from 'react-youtube';
import { useRef } from 'react';
import { useAuthStore } from '@/store/authStore';

interface VideoPlayerProps {
  videoId:    string;
  onProgress: (percent: number) => void;
  onComplete: () => void;
}

export default function VideoPlayer({ videoId, onProgress, onComplete }: VideoPlayerProps) {
  const { user } = useAuthStore();
  const playerRef = useRef<any>(null);
  const intervalRef = useRef<any>(null);
  const watchedRef = useRef(0);
  const completedRef = useRef(false);

  const startTracking = () => {
    if (intervalRef.current) return;
    intervalRef.current = setInterval(async () => {
      const player = playerRef.current;
      if (!player) return;
      const current  = await player.getCurrentTime();
      const duration = await player.getDuration();
      if (!duration) return;
      const percent = (current / duration) * 100;
      watchedRef.current = Math.max(watchedRef.current, percent);
      onProgress(percent);

      if (percent >= 80 && !completedRef.current) {
        completedRef.current = true;
        clearInterval(intervalRef.current);
        onComplete();
      }
    }, 5000);
  };

  const stopTracking = () => {
    clearInterval(intervalRef.current);
    intervalRef.current = null;
  };

  return (
    <div className="relative w-full bg-black rounded-2xl overflow-hidden shadow-2xl" style={{ aspectRatio: '16/9' }}>
      <YouTube
        videoId={videoId}
        className="w-full h-full"
        iframeClassName="w-full h-full"
        opts={{ width: '100%', height: '100%', playerVars: { rel: 0, modestbranding: 1 } }}
        onReady={e => { playerRef.current = e.target; }}
        onPlay={startTracking}
        onPause={stopTracking}
        onEnd={() => { stopTracking(); if (!completedRef.current) { completedRef.current = true; onComplete(); } }}
      />

      {user && (
        <div className="absolute bottom-12 left-4 pointer-events-none select-none z-10">
          <p className="text-white/30 text-xs">{user.name} • {user.email}</p>
        </div>
      )}
    </div>
  );
}