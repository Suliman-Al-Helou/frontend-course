'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { ClipboardList, CheckCircle, XCircle, Lock } from 'lucide-react';
import api from '@/lib/api';

export default function TasksPage() {
  const [tasks, setTasks]   = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

useEffect(() => {
  api.get('/my-courses').then(async res => {
    const result: any[] = [];
    const approved = res.data.filter((e: any) => e.status === 'approved');
    
    for (const enrollment of approved) {
      // جيب الكورس كامل مع sections
      const { data: fullCourse } = await api.get(`/courses/${enrollment.course.id}`);
      
      for (const section of fullCourse?.sections ?? []) {
        for (const lesson of section.lessons ?? []) {
          let progress = { completed: false };
          try {
            const p = await api.get(`/lessons/${lesson.id}/progress`);
            progress = p.data;
          } catch {}
          
          if (progress.completed) {
            try {
              const t = await api.get(`/lessons/${lesson.id}/task`);
              result.push({ ...t.data, lesson, course: fullCourse, unlocked: true });
            } catch {} // لا مهمة — تجاهل
          }
        }
      }
    }
    setTasks(result);
  }).finally(() => setLoading(false));
}, []);

  if (loading) return <div className="animate-pulse space-y-3">{[1,2,3].map(i => <div key={i} className="bg-card rounded-2xl h-16 border border-border" />)}</div>;

  return (
    <div>
      <h1 className="text-2xl font-bold text-foreground mb-6">المهام</h1>
      <div className="space-y-3">
        {tasks.map((task, i) => (
          <div key={i} className="flex items-center gap-4 bg-card p-4 rounded-2xl border border-border">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
              !task.unlocked ? 'bg-muted' : 'bg-primary/10'
            }`}>
              {!task.unlocked
                ? <Lock className="w-5 h-5 text-muted-foreground/30" />
                : <ClipboardList className="w-5 h-5 text-primary" />}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-foreground truncate">{task.lesson.title}</p>
              <p className="text-xs text-muted-foreground">{task.course.title}</p>
            </div>
            {task.unlocked ? (
              <Link href={`/courses/${task.course.id}/lessons/${task.lesson.id}`}
                className="text-xs bg-primary text-white px-3 py-1.5 rounded-lg hover:bg-primary/90 transition">
                حل المهمة
              </Link>
            ) : (
              <span className="text-xs text-muted-foreground">أكمل الفيديو أولاً</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}