import type { Metadata } from "next";
import "./globals.css";
// ❌ احذف هذا السطر: import ThemeProvider from "@/components/ThemeProvider";

export const metadata: Metadata = {
  title: "EduPlatform — تعلم بشكل فعّال",
  description: "منصة تعليمية محكومة تضمن تعلمك الفعلي",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
            try {
              const t = localStorage.getItem('theme');
              if (t === 'light') {
                document.documentElement.classList.remove('dark');
              } else {
                document.documentElement.classList.add('dark');
              }
            } catch(e) {}
          `,
          }}
        />
        
      </head>
      <body suppressHydrationWarning>{children}</body>
      
    </html>
  );
}
