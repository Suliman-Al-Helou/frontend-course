"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Star, Users, BookOpen, Award } from "lucide-react";
import Navbar from "@/components/landing/Navbar";
import Footer from "@/components/landing/Footer";
import Image from "next/image";
import api from "@/lib/api";

interface Instructor {
  id: number;
  name: string;
  title: string;
  avatar_url: string;
  specializations: string;
  years_experience: number;
  bio: string;
}

function InstructorCard({ ins, index }: { ins: Instructor; index: number }) {
  const specs = ins.specializations
    ? ins.specializations.split(",").map((s) => s.trim())
    : [];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.07 }}
    >
      <div className="bg-card border border-border rounded-2xl overflow-hidden hover:shadow-xl hover:shadow-primary/10 transition-all h-full flex flex-col">
        {/* Avatar */}
        <div className="bg-gradient-to-br from-blue-deep/10 to-primary/5 p-6 pb-4 text-center">
          {ins.avatar_url ? (
            <div className="relative w-12 h-12 rounded-xl overflow-hidden flex-shrink-0 border border-border">
              <Image
                src={ins.avatar_url}
                alt={ins.name}
                fill
                className="object-cover"
              />
            </div>
          ) : (
            <div className="w-20 h-20 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
              <Users className="w-8 h-8 text-primary" />
            </div>
          )}
          <h3 className="font-bold text-foreground text-base">{ins.name}</h3>
          <p className="text-muted-foreground text-xs mt-1">{ins.title}</p>
        </div>

        <div className="px-6 pb-4 flex-1 flex flex-col">
          {specs.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mb-4">
              {specs.slice(0, 3).map((s) => (
                <span
                  key={s}
                  className="bg-primary/10 text-primary text-xs px-2.5 py-1 rounded-lg font-medium"
                >
                  {s}
                </span>
              ))}
            </div>
          )}

          {ins.bio && (
            <p className="text-xs text-muted-foreground line-clamp-2 mb-4">
              {ins.bio}
            </p>
          )}

          <div className="mt-auto grid grid-cols-1 gap-2">
            <div className="bg-muted rounded-xl p-2.5 text-center">
              <Award className="w-4 h-4 text-primary mx-auto mb-1" />
              <p className="text-xs font-bold text-foreground">
                {ins.years_experience}
              </p>
              <p className="text-xs text-muted-foreground">سنوات خبرة</p>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export default function InstructorsPage() {
  const [instructors, setInstructors] = useState<Instructor[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .get("/instructors")
      .then((res) => setInstructors(res.data.data ?? res.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen bg-background font-arabic" dir="rtl">
      <Navbar />

      <div className="bg-gradient-to-br from-blue-deep to-blue-mid pt-28 pb-16 px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="inline-flex items-center gap-2 bg-white/10 text-white rounded-full px-4 py-1.5 text-sm font-medium mb-4">
            <Award className="w-4 h-4" /> فريق المدربين
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">
            تعرّف على مدربينا
          </h1>
          <p className="text-white/70 text-lg">
            خبراء ومتخصصون يجمعهم شغف التعليم وبناء الجيل التقني العربي
          </p>
        </motion.div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
          </div>
        ) : instructors.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground">
            <Users className="w-12 h-12 mx-auto mb-4 opacity-30" />
            <p>لا يوجد مدربون بعد</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {instructors.map((ins, i) => (
              <InstructorCard key={ins.id} ins={ins} index={i} />
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
