'use client';

// src/app/(auth)/reset-password/page.tsx

// 1. Imports
import { useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { motion } from 'framer-motion';
import { Code2, Eye, EyeOff } from 'lucide-react';
import api from '@/lib/api';

// 2. Types
interface ResetForm {
  password: string;
  confirm:  string;
}

// 3. Sub Components
function Logo() {
  return (
    <Link href="/" className="inline-flex items-center gap-2 mb-4">
      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-mid to-blue-light flex items-center justify-center">
        <Code2 className="w-5 h-5 text-white" />
      </div>
      <span className="text-xl font-bold text-blue-deep">
        future <span className="text-primary">house</span>
      </span>
    </Link>
  );
}

function SuccessState() {
  return (
    <div className="text-center space-y-4">
      <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
        <span className="text-3xl text-green-600">✓</span>
      </div>
      <h3 className="font-bold text-blue-deep text-lg">تم التحديث بنجاح!</h3>
      <Link
        href="/login"
        className="w-full h-11 bg-primary hover:bg-primary/90 text-white rounded-xl font-semibold inline-flex items-center justify-center transition-colors"
      >
        تسجيل الدخول الآن
      </Link>
    </div>
  );
}

// 4. Main Component
export default function ResetPasswordPage() {
  const searchParams = useSearchParams();
  const token        = searchParams.get('token');

  const [form,     setForm]     = useState<ResetForm>({ password: '', confirm: '' });
  const [showPass, setShowPass] = useState(false);
  const [error,    setError]    = useState('');
  const [loading,  setLoading]  = useState(false);
  const [done,     setDone]     = useState(false);

  const updateField = (field: keyof ResetForm) =>
    (e: React.ChangeEvent<HTMLInputElement>) =>
      setForm(prev => ({ ...prev, [field]: e.target.value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (form.password !== form.confirm) {
      setError('كلمتا المرور غير متطابقتين');
      return;
    }
    setError('');
    setLoading(true);
    try {
      // TODO: POST /api/auth/reset-password في Laravel
      // await api.post('/auth/reset-password', { token, password: form.password });
      await new Promise(res => setTimeout(res, 800)); // مؤقت
      setDone(true);
    } catch (err: any) {
      setError(err.response?.data?.message || 'حدث خطأ، تأكد من صلاحية الرابط');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="min-h-screen bg-gradient-to-br from-blue-pale via-white to-blue-50 flex items-center justify-center p-4"
      dir="rtl"
    >
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        {/* Header */}
        <div className="text-center mb-8">
          <Logo />
          <h1 className="text-2xl font-bold text-blue-deep">كلمة مرور جديدة</h1>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-xl shadow-blue-100/60 border border-blue-100 p-8">
          {!done ? (
            <form onSubmit={handleSubmit} className="space-y-5">

              {/* New password */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">كلمة المرور الجديدة</label>
                <div className="relative">
                  <input
                    type={showPass ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={form.password}
                    onChange={updateField('password')}
                    required
                    className="w-full h-11 rounded-xl border border-input bg-background px-4 pl-10 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass(prev => !prev)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Confirm */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">تأكيد كلمة المرور</label>
                <input
                  type="password"
                  placeholder="••••••••"
                  value={form.confirm}
                  onChange={updateField('confirm')}
                  required
                  className="w-full h-11 rounded-xl border border-input bg-background px-4 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
                />
              </div>

              {/* Error */}
              {error && (
                <div className="bg-red-50 text-red-600 text-sm rounded-lg px-4 py-3 border border-red-100">
                  {error}
                </div>
              )}

              {/* Submit */}
              <button
                type="submit"
                disabled={loading}
                className="w-full h-11 bg-primary hover:bg-primary/90 disabled:opacity-60 text-white rounded-xl font-semibold transition-colors"
              >
                {loading ? 'جارٍ التحديث...' : 'تحديث كلمة المرور'}
              </button>
            </form>
          ) : (
            <SuccessState />
          )}
        </div>
      </motion.div>
    </div>
  );
}